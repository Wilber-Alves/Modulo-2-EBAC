using UnityEngine;
using DG.Tweening;

public class My_First_Animation : MonoBehaviour
{
    public float duration = 30;
    public Ease easeType = Ease.Linear;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        transform.DOMoveY(133, duration).SetEase(easeType);
    }
}
