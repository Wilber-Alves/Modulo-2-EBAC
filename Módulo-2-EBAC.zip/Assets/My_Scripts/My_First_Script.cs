using UnityEngine;

public class My_First_Script : MonoBehaviour
{   public float position;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        position = PlayerPrefs.GetFloat("position",1);
        position++;

        PlayerPrefs.SetFloat("position", position);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
